package com.crm.finalMockA6.BaseClass;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import com.crm.finalMockA6.JavaUtility.JavaUtility;
import com.crm.finalMockA6.Pom.VTigerHome;
import com.crm.finalMockA6.Pom.VTigerLogin;

public class BaseClassVtiger {
	public static WebDriver driver;
    
	@BeforeClass
	public void preCondition() throws IOException
	{
		String browser = JavaUtility.getInputData("browser");
		String url = JavaUtility.getInputData("VURL");

		if(browser.equalsIgnoreCase("chrome"))
		{
			driver = new ChromeDriver();
		}else if(browser.equalsIgnoreCase("edge"))
		{
			driver = new EdgeDriver();
		}else {
			driver = new ChromeDriver();
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.get(url);
	}
	 
	@BeforeMethod
	public void login() throws IOException
	{
		VTigerLogin login = new VTigerLogin(driver);
		login.login();
	}
	
	@AfterMethod
	public void logout()
	{
		VTigerHome home = new VTigerHome(driver);
		home.logout(driver);
	}
	
	@AfterClass
	public void postCondition()
	{
		driver.quit();
	}

}
