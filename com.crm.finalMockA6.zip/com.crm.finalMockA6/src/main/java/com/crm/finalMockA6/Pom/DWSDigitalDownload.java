package com.crm.finalMockA6.Pom;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DWSDigitalDownload {
	public DWSDigitalDownload(WebDriver driver) {
		PageFactory.initElements(driver,this);
	}
	private @FindBy(xpath="(//a[contains(text(),'Digital downloads')])[1]") WebElement digitalDownload;
	private @FindBy(xpath = "//input[@value='Add to cart']") List<WebElement> prod;
	private @FindBy(xpath = "//span[text()='Shopping cart']") WebElement c;

	public void digitalDownload() {
		digitalDownload.click();
	}
	public void clickOnAllProducts() {
		for (WebElement webElement : prod) {
			webElement.click();
		}
	}
	public void cart()
	{
		c.click();
	}

}
