package com.crm.finalMockA6.JavaUtility;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Random;

public class JavaUtility {

	public static String getInputData(String key) throws IOException
	{
		FileInputStream fis = new FileInputStream("A:\\Qspiders2.0\\oop\\com.crm.finalMockA6\\src\\main\\resources\\Properties\\propertiesForDWS.properties");
		Properties p = new Properties();
		p.load(fis);
		return p.getProperty(key);
	}
	
	public static int generateRandomNumber(int limit)
	{
		Random r = new Random();
		return r.nextInt(limit);
	}
}
