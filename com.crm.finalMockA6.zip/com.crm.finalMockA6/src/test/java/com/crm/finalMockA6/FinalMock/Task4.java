package com.crm.finalMockA6.FinalMock;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.crm.finalMockA6.BaseClass.BaseClassVtiger;
import com.crm.finalMockA6.FileUtility.FileUtility;
import com.crm.finalMockA6.JavaUtility.JavaUtility;
import com.crm.finalMockA6.Pom.VTigerHome;
import com.crm.finalMockA6.Pom.VTigerOrganisation;


@Listeners(com.crm.finalMockA6.Listerners.ListenerVtiger.class)
public class Task4 extends BaseClassVtiger{
	@Test
	public void Task4() throws EncryptedDocumentException, IOException {
		VTigerHome home = new VTigerHome(driver);
		home.organizations();
		
		int row = 0;
		VTigerOrganisation org = new VTigerOrganisation(driver);
		org.plusIcon();
		String orgName= FileUtility.getData("Vtiger", 1, 2);
		
		
		
		org.organizationName(orgName+JavaUtility.generateRandomNumber(1000));
		org.group();
		org.saveBtn();
		
		assertTrue((org.getCreatedOrgText().getText()).contains(orgName));

	}
}
