package com.crm.finalMockA6.FinalMock;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.crm.finalMockA6.BaseClass.BaseClassDWS;
import com.crm.finalMockA6.Pom.DWSCart;
import com.crm.finalMockA6.Pom.DWSDigitalDownload;


@Listeners(com.crm.finalMockA6.Listerners.Listeners.class)
public class Task3 extends BaseClassDWS{
	@Test
	public void task3(){
		DWSDigitalDownload digitalDownload = new DWSDigitalDownload(driver);
		DWSCart cart = new DWSCart(driver);
		digitalDownload.digitalDownload();
		digitalDownload.clickOnAllProducts();
		
		
		digitalDownload.cart();
		List<WebElement> prices = cart.prices();
		double highPrice = 0;
		for (WebElement webElement : prices) {
			if(Double.parseDouble(webElement.getText())>highPrice) 
			{
				highPrice=Double.parseDouble(webElement.getText());
			}
		}
		driver.findElement(By.xpath("//span[text()='"+highPrice+"0']/../../td/input"));
		cart.updateCart();
		
		
		
	}
}
