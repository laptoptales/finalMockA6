package com.crm.finalMockA6.FinalMock;

import java.io.IOException;
import java.util.Set;

import org.apache.poi.EncryptedDocumentException;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.crm.finalMockA6.BaseClass.BaseClassDWS;
import com.crm.finalMockA6.FileUtility.FileUtility;
import com.crm.finalMockA6.Pom.DWSFacebook;


@Listeners(com.crm.finalMockA6.Listerners.Listeners.class)
public class Task2 extends BaseClassDWS {
	@Test
	public void Task2() throws EncryptedDocumentException, IOException
	{
		DWSFacebook dwsFacebook  =new DWSFacebook(driver);
		
		String homeHandle = driver.getWindowHandle();
		dwsFacebook.facebook();
		Set<String> handles = driver.getWindowHandles();
		for (String string : handles) {
			if(!string.equals(homeHandle)) {
				driver.switchTo().window(string);
				dwsFacebook.createAccount();
				String facebookHandle = driver.getWindowHandle();
				
				Set<String> allHandles = driver.getWindowHandles();
				for (String string2 : allHandles) {
					if(! (string2.equals(facebookHandle) || string2.equals(homeHandle))) {
						driver.switchTo().window(string2);
						dwsFacebook.firstName(FileUtility.getData("Facebook", 1, 2));
						dwsFacebook.lastName(FileUtility.getData("Facebook", 1, 3));
						dwsFacebook.email(FileUtility.getData("Facebook", 1, 4));
						dwsFacebook.reMail(FileUtility.getData("Facebook", 1, 4));
						dwsFacebook.password(FileUtility.getData("Facebook", 1, 5));
						
						dwsFacebook.day(FileUtility.getData("Facebook", 1, 6));
						dwsFacebook.month(FileUtility.getData("Facebook", 1, 7));
						dwsFacebook.year(FileUtility.getData("Facebook", 1, 8));
						dwsFacebook.gender();
						
						driver.switchTo().window(homeHandle);
					}
				}
			}
		}
		
		
		
	}
}
